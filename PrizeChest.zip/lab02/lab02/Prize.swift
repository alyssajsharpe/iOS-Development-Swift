//Alyssa Sharpe
//CS356 Lab 2
//Prize.swift
//4.24.2020

import Foundation

struct Prize{
    //Stored Properties
    var name:String = "UNKNOWN"
    var price:Double = 0.0
    var manufacturer:String = "UNKNOWN"
    var year:Int = 0
    
    //Type Properties
    let expensive = 1000.00
    let jackpot = 10000.00
    static let prizeVar = Prize(name:"BOOBY PRIZE", price: 0.0, manufacturer:"N/A", year:0)
    
    //Computed Properties
    //i
    var desc: String {
        if(price == 0.0){
            return "free"
        } else if (price > 0.0 && price < 1000.00){
            return "inexpensive"
        }
        return "expensive"
    }//end description
    
    //ii
    var isJackpot:Bool {
        return price > 10000.00
    }
    
    //iii
    var output:String{
        return String(format: "the %@ %d %@ worth $%.2f", desc,year,manufacturer,price)
    }
    //Methods
    //d
    func isHigher(p:Prize) -> Bool {
        return p.price > price
    }
}//end struct Prize








