//Alyssa Sharpe
//CS356 Lab 2
//PrizeDoors.swift
//4.24.2020
import Foundation

struct PrizeDoors{
    //Stored Properties
    var chest = PrizeChest(isPopulated:true)
    var doorArr:[Prize] = [Prize.prizeVar,Prize.prizeVar,Prize.prizeVar]
    
    //Computed Property
    var doorNum: Int?{
        for i in 0...2 {
            if(doorArr[i].name == "BOOBY PRIZE"){
                return i
            }
        }//end for
        return nil
    }//end doorNum
    
    //Methods
    func returnPrize(doorNum:Int) -> Prize?{
        if doorNum >= 0 && doorNum <= 2{
            return doorArr[doorNum]
        } else {
            return nil
        }
    }//end returnPrize
    
    //Resetting Door Array
    mutating func reset(){
        chest.shufflePrizes()
        for i in 0...2{
            doorArr[i] = chest.prizeArr[i]
        }
        let randDoor = Int.random(in:0...2)
        doorArr[randDoor] = Prize.prizeVar
    }//end reset
}//end PrizeDoors Struct
