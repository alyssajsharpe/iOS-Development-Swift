//Alyssa Sharpe
//CS356 Lab 2
//PrizeChest.swift
//4.24.2020

import Foundation

struct PrizeChest {
    //Stored property
    //a
    var prizeArr:[Prize] = []
    //Initializer
    //b
    init(isPopulated:Bool){
        if(isPopulated){
            prizeArr.append(Prize(name: "Corvette", price: 20000.00, manufacturer: "Chevy", year: 2003))
            prizeArr.append(Prize(name: "Model-T", price: 14000.00, manufacturer: "Ford", year: 1928))
            prizeArr.append(Prize(name: "washing-machine", price: 650.00, manufacturer: "Maytag", year: 2009))
            prizeArr.append(Prize(name: "Cruise", price: 5000.00, manufacturer: "Canival", year: 2010))
            prizeArr.append(Prize(name: "Mansion", price: 990000.00, manufacturer: "Bob's", year: 2013))
            prizeArr.append(Prize(name: "organ", price: 2500.00, manufacturer: "Worlitzer", year: 1999))
            prizeArr.append(Prize(name: "Switch", price: 500.00, manufacturer: "Nintendo", year: 2017))
            prizeArr.append(Prize(name: "Animal Crossing:New Horizons", price: 60.00, manufacturer: "Nintendo", year: 2020))
        }
    }//end Init
    
    //Computed Properties
    //i
    var randIndex: Int?{
        let x = Int.random(in:0...6)
        if(x < 0 || x > 6){
            return nil
        }
        return x
    }
    
    //ii
    var randPrize: Prize?{
        let rand = randIndex ?? -1
        return prizeArr[rand]
    }
    
   //Functions
    mutating func shufflePrizes(){
        for i in 0...6 {
            let prize1 = prizeArr[i]
            let rand = randIndex
            let prize2 = prizeArr[rand!]
            prizeArr[i] = prize2
            prizeArr[rand!] = prize1
        }//end for loop
    }//end shufflePrizes
}//end struct PrizeChest
