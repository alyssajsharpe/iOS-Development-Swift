//Alyssa Sharpe
//CS356 Lab 2
//main.swift
//4.24.2020

import Foundation
//a
func outputPrizes(doors:PrizeDoors){
    for i in -1...4{
        let prize = doors.returnPrize(doorNum: i)
        if (prize != nil) {
            if(prize?.isJackpot == true){
                print("JACKPOT on door #\(i+1)! You won \(doors.chest.prizeArr[i].output)!")
            } else {
                print("Sorry, you did not win the Jackpot...")
            }
        } else if(prize == nil){
            print("ERROR")
        }
    }//end for
}//end outputPrizes

//b Creating PrizeDoors object
var prizeDoors = PrizeDoors(chest: PrizeChest(isPopulated: true))
prizeDoors.reset()

//c Outputting prizes
outputPrizes(doors: prizeDoors)

//d Outputting door number that holds booby prize
let door = prizeDoors.doorNum
print("Door number containing Booby Prize: \(door ?? -1)")

//e Resetting doors
prizeDoors.reset()

//f Outputting prizes
outputPrizes(doors: prizeDoors)








