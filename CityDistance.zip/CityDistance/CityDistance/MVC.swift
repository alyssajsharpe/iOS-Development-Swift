//
//  MVC.swift
//  CityDistance
//
//  Created by user168926 on 5/23/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation
import CoreLocation

class MVC: NSObject, CLLocationManagerDelegate {
    let locationManager: CLLocationManager = CLLocationManager()
    //Optional CLLocation
    var currentLocation: CLLocation? = nil
    static let locationNotification = Notification.Name(rawValue: "Location updated")
    
    // the globally accessible shared instance
    static let sharedInstance = MVC()
    
    //Creating empty array
    var cityArr:[City] = []
    //Creating empty dictionary
    var dict:[String: City] = [:]
    
    override init(){
        let city1 = City(name: "Medford", state: "Oregon", location: CLLocation(latitude: 42.3266667, longitude: -122.8744444))
        let city2 = City(name: "Seattle", state: "Washington", location: CLLocation(latitude: 47.6063889, longitude: -122.3308333))
        let city3 = City(name: "Grants Pass", state: "Oregon", location: CLLocation(latitude: 42.4391667, longitude: -123.3272222))
        let city4 = City(name: "Applegate", state: "Oregon", location: CLLocation(latitude: 42.2570662, longitude: -123.1683833))
        let city5 = City(name: "San Francisco", state: "California", location: CLLocation(latitude: 37.775, longitude: -122.4183333))
        //Adding cities to array
        cityArr.append(city1)
        cityArr.append(city2)
        cityArr.append(city3)
        cityArr.append(city4)
        cityArr.append(city5)
        //Adding cities to dictionary
        dict = [city1.name + "," + city1.state: city1,city2.name + "," + city2.state: city2, city3.name + "," + city3.state: city3, city4.name + "," + city4.state: city4, city5.name + "," + city5.state: city5]
        
        super.init()
    }//end init
    
    //Access city in dictionary
    func returnCityDict(name: String) -> City? {
        if dict.keys.contains(name){
                return dict[name]
            }
            return nil
        }
    //Access city in array
    func returnCityArr(city: Int) -> City? {
        return cityArr[city]
    }
    
    //Adding city to dictionary and array
    func addCity(city:City){
        dict[city.name + "," + city.state] = city
        cityArr.append(city)
    }
    
    // computed properties
    var numCities: Int {
        return cityArr.count
    }
    
    override var description: String {
        return "The cities are:\n \(cityArr)"
    }
    
    //Location methods
    //ViewDidLoad code
    func getLocation(){
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    //Invoked when location changes
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        currentLocation = locations.last!
        //Updating notification center
        NotificationCenter.default.post(name: MVC.locationNotification, object: self)
    }
    //Invoked when location error occurs
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error){
        MVC.sharedInstance.currentLocation = nil
    }
}//end MVC struct
