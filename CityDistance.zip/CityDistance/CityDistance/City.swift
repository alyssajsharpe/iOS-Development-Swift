//
//  City.swift
//  CityDistance
//
//  Created by user168926 on 5/23/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation
import CoreLocation
struct City : CustomStringConvertible {
    
    // stored properties
    let name: String
    let state: String
    let location: CLLocation
    
    // initializers
    init (name: String, state: String, location: CLLocation) {
        self.name = name
        self.state = state
        self.location = location
    }

    init (name: String, state: String, latitude: Double, longitude: Double) {
        self.name = name
        self.state = state
        self.location = CLLocation(latitude: latitude, longitude: longitude)
    }
    
    // computed properties
    var cityStateName: String {
        return "\(name), \(state)"
    }
    
    var description: String {
        return String(format: "\(name), \(state) is at latitude %.2f, longitude %.2f", location.coordinate.latitude, location.coordinate.longitude)
    }
}
