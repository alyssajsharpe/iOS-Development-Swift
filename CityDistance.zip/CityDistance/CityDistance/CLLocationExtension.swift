//
//  CLLocationExtension.swift
//  CityDistance
//
//  Created by user168926 on 5/9/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation
import CoreLocation

let km = 1000.00
let getMiles = 0.621371

extension CLLocation {
    func distance(city: CLLocation) -> Double {
        return distance(from: city) / km * (getMiles)
    }
}
