//
//  ViewController.swift
//  CityDistance
//
//  Created by user168926 on 5/9/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit
import CoreLocation

//Constants
let errorMsg:String = "Error: could not calculate distance between the two cities."

class ViewController: UIViewController, CLLocationManagerDelegate,UIPickerViewDelegate,UIPickerViewDataSource {
    let theModel = MVC()
    let locationManager: CLLocationManager = CLLocationManager()
    var selectedRow: Int?
    //Labels
    @IBOutlet weak var currentLocationDisplay: UILabel!
    @IBOutlet weak var distanceDisplay: UILabel!
    
    func distanceCalc(c:City){
        if(theModel.currentLocation != nil){
            let dist = theModel.currentLocation?.distance(city: c.location)
            distanceDisplay.text = String(format: "The distance to \(c.name), \(c.state) is %.2f km.",dist!)
        } else {
            distanceDisplay.text = errorMsg
        }
    }
    //Choosecity func
    func chooseCity(cityNum: Int){
        //Creating city variable holding choosen city
        let returnedCity = theModel.returnCity(city: cityNum)
        //Distance between cityChoosen and current
        distanceCalc(c: returnedCity)
    }

    //Location Methods
    //Invoked when location changes
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        let lastLocation: CLLocation = locations.last!
        //display the location on your label
        theModel.currentLocation = lastLocation
        //currentLocationDisplay.text = "Current Location:\n Latitude: \(theModel.currentLocation?.coordinate.latitude ?? -1) \nLongitude: \(theModel.currentLocation?.coordinate.longitude ?? -1)"
        currentLocationDisplay.text = String(format: "Current Location:\n Latitude: %.2f \nLongitude: %.2f", theModel.currentLocation?.coordinate.latitude ?? -1, theModel.currentLocation?.coordinate.longitude ?? -1)
        if(selectedRow != nil){
            let recalcCity = theModel.returnCity(city: selectedRow!)
            distanceCalc(c: recalcCity)
        }
    }
    //Invoked when location error occurs
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error){
        //display the following:
        currentLocationDisplay.text = "Problem with getting location:\n \(error)"
        theModel.currentLocation = nil
       }
    
    // UIPickerViewDelegate protocol methods
    
    // what to display on a specific row
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String("\(theModel.returnCity(city: row).name), \(theModel.returnCity(city: row).state)")
    }
    
    // called when a selection is made
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        chooseCity(cityNum: row)
        selectedRow = row
    }

    // UIPickerViewDataSource protocol methods
    
    // # of components in each row
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // number of rows
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return theModel.cityArr.count
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Make me the delegate
        locationManager.delegate = self
        //request user authorization
        locationManager.requestWhenInUseAuthorization()
        //start getting location updates
        locationManager.startUpdatingLocation()
    }
}//end viewController

