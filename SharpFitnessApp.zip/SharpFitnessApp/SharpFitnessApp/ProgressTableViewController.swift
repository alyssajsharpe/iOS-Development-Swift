//
//  ProgressTableViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 12/1/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

var selectedProgress: Int = 0


class ProgressTableViewController: UITableViewController {
    
    static func currentTime() -> String {
        let date = Date()
        let calendar = Calendar.current
        //let day = calendar.component(.day, from: date)
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        return "\(hour):\(minutes)"
    }

    let tempExerciseArray = FitnessModel.sharedInstance.userExerciseArr
    let tempFoodArray = FitnessModel.sharedInstance.userfoodArr
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedProgress = indexPath.row
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var returnValue = 0

        //if(FitnessModel.sharedInstance.numFoodProgress()! > 0){
        //    returnValue = FitnessModel.sharedInstance.numFoodProgress()!
        //}
        
        returnValue = (FitnessModel.sharedInstance.numFoodProgress() ?? 0) + (FitnessModel.sharedInstance.numExerciseProgress() ?? 0)
        
        //return whatever was successful in if statement
        return returnValue
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "")
        
        if(indexPath.row == 0){
            cell = tableView.dequeueReusableCell(withIdentifier: "FoodProgressDB", for: indexPath)
        
            if let food = FitnessModel.sharedInstance.getFoodEaten(index:indexPath.row){
                if(FitnessModel.sharedInstance.isFoodEmpty() == false){
                //let foodEaten = FitnessModel.sharedInstance.getFoodProgress(index: selectedProgress)
                
                    cell?.textLabel?.text = food.name
                    let cals = food.servingsConsumed * food.caloriesPerServing
                    cell?.detailTextLabel?.text = "Calories: +\(cals)"
            }
        }
        return cell!
        } else if(indexPath.row == 1){
            cell = tableView.dequeueReusableCell(withIdentifier: "ExerciseProgressDB", for: indexPath)
            
            if let exercised = FitnessModel.sharedInstance.getExercised(index: indexPath.row){
                if(FitnessModel.sharedInstance.isExerciseEmpty() == false){
                    cell?.textLabel?.text = exercised.name
                    cell?.detailTextLabel?.text = "Calories: -\(exercised.caloriesBurned)"
                }
            }
            return cell!
        }
        return cell!
    }//end table cell view
    
    //cell title
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Logged Food & Exercises"
    }//func
}


