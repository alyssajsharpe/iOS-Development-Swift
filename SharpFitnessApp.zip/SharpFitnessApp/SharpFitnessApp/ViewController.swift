//
//  ViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/13/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

class ViewController: UIViewController{

    @IBOutlet weak var emailOutlet: UITextField!
    @IBOutlet weak var passwordOutlet: UITextField!
    @IBOutlet weak var logInButton: UIButton!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        emailOutlet.text = ""
        passwordOutlet.text = ""
        
        setupTextFields()
    }

    //if user has to make an account
    @IBAction func continueButtonAction(_ sender: Any) {
        //dismiss keyboard
        emailOutlet.resignFirstResponder()
        passwordOutlet.resignFirstResponder()
        
        //Checking for empty parameters
        if emailOutlet.text?.isEmpty == false && passwordOutlet.text?.isEmpty == false{
            //check if username exists
            if (!FitnessModel.sharedInstance.ifEmailTaken(email: emailOutlet.text!)){
                //username does not exist, setting global variables
                FitnessModel.myGlobalVariables.email = emailOutlet.text!
                FitnessModel.myGlobalVariables.password = passwordOutlet.text!
                //switching view controller to signup
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let signupViewController = storyBoard.instantiateViewController(withIdentifier: "SignupViewController") as! SignupViewController
                self.present(signupViewController, animated: true, completion: nil)
            }
        } else{
            errorLabel.text = "Please enter in a valid username and password."
        }
    }
    //keyboard done button
    func setupTextFields() {
          let toolbar = UIToolbar()
          let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
          let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
          
          toolbar.setItems([flexSpace, doneButton], animated: true)
          toolbar.sizeToFit()
          
          emailOutlet.inputAccessoryView = toolbar
          passwordOutlet.inputAccessoryView = toolbar
      }
      
      @objc func doneButtonTapped() {
          view.endEditing(true)
      }
    
}

