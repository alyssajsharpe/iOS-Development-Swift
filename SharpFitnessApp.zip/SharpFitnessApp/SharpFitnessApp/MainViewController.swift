//
//  MainViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/20/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit



class MainViewController: UIViewController {
    @IBOutlet var progressBarView: UIProgressView!
    @IBOutlet weak var caloriesLeftOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        caloriesLeftOutlet.text = "\(FitnessModel.sharedInstance.loggedInUser?.maxCalories ?? 0)"
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        caloriesLeftOutlet.text = "\(FitnessModel.sharedInstance.loggedInUser?.maxCalories ?? 0)"
        //FitnessModel.sharedInstance.loggedInUser = FitnessModel.sharedInstance.returnUserWithEmail(email: "jimbob@gmail.com")
        //progressBarView.progress = Float(FitnessModel.sharedInstance.loggedInUser!.maxCalories/100);
    }
}
