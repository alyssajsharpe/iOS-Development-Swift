//
//  LogginViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/13/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

class LogginViewController: UIViewController {

    @IBOutlet weak var logInButton: UIButton!
    @IBOutlet weak var forgotPasswordButton: UIButton!
    @IBOutlet weak var emailOutlet: UITextField!
    @IBOutlet weak var passwordOutlet: UITextField!
    
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTextFields()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func logInButtonAction(_ sender: UIButton) {
        
        if(emailOutlet.text?.isEmpty == false && passwordOutlet.text?.isEmpty == false){
            //check if username is in database
            if(FitnessModel.sharedInstance.checkLoggin(username:emailOutlet.text!, pass:passwordOutlet.text!) == true){
                //Setting global variable loggedInUser to the user that logged in
                FitnessModel.sharedInstance.loggedInUser = FitnessModel.sharedInstance.returnUserWithEmail(email: emailOutlet.text!)
                //log user in
                let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let mainViewController = storyBoard.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
                self.present(mainViewController, animated: true, completion: nil)
            } else{
                errorLabel.text = "Invalid username or password was entered."
            }
        } else{
            errorLabel.text = "You must enter in a username and password to log in."
        }
        
    }
    @IBAction func forgotPasswordButtonAction(_ sender: Any) {
        
        
    }
    
    //keyboard done button
    func setupTextFields() {
          let toolbar = UIToolbar()
          let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
          let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
          
          toolbar.setItems([flexSpace, doneButton], animated: true)
          toolbar.sizeToFit()
          
          emailOutlet.inputAccessoryView = toolbar
          passwordOutlet.inputAccessoryView = toolbar
      }
      
      @objc func doneButtonTapped() {
          view.endEditing(true)
      }
}//end logginviewcontroller
