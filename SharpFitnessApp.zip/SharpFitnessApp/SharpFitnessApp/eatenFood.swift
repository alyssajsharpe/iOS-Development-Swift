//
//  eatenFood.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 12/1/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation

class eatenFood: Comparable{
    
    //Variables
    let name:String
    let meal:String
    let caloriesPerServing:Int
    let servingsConsumed:Int
    
    init(name:String, meal:String, caloriesPerServing:Int, servingsConsumed:Int){
        self.name = name
        //Breakfast, lunch, dinner, snack
        self.meal = meal
        self.caloriesPerServing = caloriesPerServing
        self.servingsConsumed = servingsConsumed
    }
    
    //Comparable functions
    static func < (first: eatenFood, second: eatenFood) -> Bool{
        if first.name == second.name{
            return first.name < second.name
        } else{
            return first.name < second.name
        }
    }
    
    static func == (first: eatenFood, second:eatenFood) -> Bool{
        return first.name == second.name
    }
}//end eatenFood
