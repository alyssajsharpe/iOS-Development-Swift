//
//  ItemViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 12/2/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

class ItemViewController: UIViewController {

    @IBOutlet weak var typeOfItemOutlet: UILabel!  //food or exercise
    @IBOutlet weak var nameOfItemOutlet: UILabel!
    @IBOutlet weak var mealOutlet: UILabel!
    @IBOutlet weak var caloriesOutlet: UILabel!
    @IBOutlet weak var servingsConsumedOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        var foodChoice = FitnessModel.sharedInstance.foodChoice
        foodChoice = FitnessModel.sharedInstance.userfoodArr[selectedProgress]
        
        if(foodChoice != nil){
            //populate the text
            typeOfItemOutlet.text = "Food"
            nameOfItemOutlet.text = foodChoice?.name
            mealOutlet.text = "Meal: \(foodChoice?.meal ?? "")"
            
            let caloriesConsumed = foodChoice!.servingsConsumed * foodChoice!.caloriesPerServing
            
            caloriesOutlet.text = "Calories consumed: \(caloriesConsumed)"
            servingsConsumedOutlet.text = "Servings Consumed: \(foodChoice?.servingsConsumed ?? 0)"

        }
    }
}
