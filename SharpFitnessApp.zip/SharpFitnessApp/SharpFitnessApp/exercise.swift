//
//  exercise.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/13/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation
class Exercise : Comparable{
    
    let name:String
    let caloriesPerMin:Int
    
    init(name:String, caloriesPerMin:Int){
        self.name = name
        self.caloriesPerMin = caloriesPerMin
    }
    
    //Comparable functions
    static func < (first: Exercise, second: Exercise) -> Bool{
        if first.name == second.name{
            return first.name < second.name
        } else{
            return first.name < second.name
        }
    }
    
    static func == (first: Exercise, second:Exercise) -> Bool{
        return first.name == second.name
    }
}//end exercise.swift
