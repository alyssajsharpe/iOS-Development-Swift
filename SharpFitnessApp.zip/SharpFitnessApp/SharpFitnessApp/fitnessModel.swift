//
//  fitnessModel.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/13/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation
class FitnessModel{
    
    struct myGlobalVariables{
        static var email = ""
        static var password = ""
        //remove logged in user after done with testing
        //static var loggedInUser = User(firstName: "Jim",lastName: "Bob",email: "jimbob@gmail.com",password: "1234",goal: "Lose Weight",currWeight: 200,goalWeight: 180,age: 34,maxCalories: 2500)
    }
    //Singleton
    static let sharedInstance = FitnessModel()
    var loggedInUser:User? = User(firstName: "Jim",lastName: "Bob",email: "jimbob@gmail.com",password: "1234",goal: "Lose Weight",currWeight: 200,goalWeight: 180,age: 34,maxCalories: 2500)
    var foodChoice:eatenFood? = nil
    var exerciseChoice:Exercised? = nil
    
    var exerciseSelected:Exercise? = nil
    var exerciseSelectedIndex:Int? = nil
    
    //Dictionary & array for users
    var userDict: [String:User] = [:]
    var userArr:[User] = []
    
    //Dictionary for food
    var foodDict: [String:Food] = [:]
    var foodArr:[Food] = []
    
    //Dictionary for exercise
    var exerciseDict: [String:Exercise] = [:]
    var exerciseArr:[Exercise] = []
    
    //Exercises that are completed by logged in user
    var userExerciseDict: [String:Exercised] = [:]
    var userExerciseArr:[Exercised] = []
    
    //For food that is eaten by logged in user
    var userfoodDict: [String:eatenFood] = [:]
    var userfoodArr:[eatenFood] = []
    
    
    //init
    init(){
        //users
        let user1 = User(firstName: "Alyssa", lastName: "Sharpe", email: "alyssajsharpe@gmail.com", password: "1234", goal: "Maintain", currWeight: 125, goalWeight: 120, age: 22, maxCalories:2000)
        let user2 = User(firstName: "Billy", lastName: "Bob", email: "billybob@gmail.com", password: "1234", goal: "Maintain", currWeight: 125, goalWeight: 125, age: 22, maxCalories:2500)
        //food
        let food1 = Food(foodName: "Sandwich", category: "Lunch", caloriesPerServing: 250)
        
        //exercise
        let ex1 = Exercise(name: "Running", caloriesPerMin: 11)
        let ex2 = Exercise(name: "Biking", caloriesPerMin: 9)
        let ex3 = Exercise(name: "Yoga", caloriesPerMin: 5)
        let ex4 = Exercise(name: "Swimming", caloriesPerMin: 10)
        
        //Adding users to dictionary & array
        userDict = [user1.email: user1]
        userArr.append(user1)
        
        userDict = [user2.email: user2]
        userArr.append(user2)
        
        //Adding food to dict & arr
        foodDict = [food1.foodName:food1]
        foodArr.append(food1)
        
        //Adding exercise to dict & arr
        exerciseDict = [ex1.name:ex1]
        exerciseArr.append(ex1)
        
        exerciseDict = [ex2.name:ex2]
        exerciseArr.append(ex2)
        
        exerciseDict = [ex3.name:ex3]
        exerciseArr.append(ex3)
        
        exerciseDict = [ex4.name:ex4]
        exerciseArr.append(ex4)
        
    }//end init
    
    // **** User Functions ****
    func checkLoggin(username:String, pass:String)->Bool{
        print("got into function")
        if userDict.keys.contains(username){
            let tempUser = userDict[username]
            print("contains username")
            if tempUser?.password == pass{
                print("password matches")
                //correct loggin info was passed in
                return true
            }
        }
        //invalid loggin info
        return false
    }
    
    func numExercise() -> Int { return exerciseArr.count}
    func getExercise(index: Int)-> Exercise {return exerciseArr[index]}
    
    
    func numExerciseProgress()->Int? {return userExerciseArr.count}
    func getExerciseProgress(index:Int)-> Exercised {return userExerciseArr[index]}
    
    func numFoodProgress()->Int? {return userfoodArr.count}
    func getFoodProgress(index:Int)-> eatenFood{return userfoodArr[index]}
    
    //check if email is taken
    func ifEmailTaken(email:String)->Bool{
        if userDict.keys.contains(email){
            return true
        }
        return false
    }
    
    //get password from inputted email - email is checked if valid before calling this func
    func getPassword(email:String)->String{
        return userDict[email]!.password
    }
    
    //Access user in dict with name
    func returnUserDict(name:String)->User?{
        if userDict.keys.contains(name){
            return userDict[name]
        }
        return nil
    }
    
    //Access user in dict with email
    func returnUserWithEmail(email:String)->User?{
        if userDict.keys.contains(email){
            return userDict[email]
        }
        return nil
    }
    
    //Access user in arr
    func returnUserArr(user:Int)->User?{
        return userArr[user]
    }
    
    //Add user to dictionary alphabetically
    func addUserDict(user:User){
        userDict[user.email] = user
    }
    //Adding person to array alphabetically
    func addUserArr(user:User){
        for i in 0..<userArr.count{
            if user < userArr[i]{
                userArr.insert(user, at: i)
                break
            }
            if i == userArr.count-1 {
                userArr.append(user)
                break
            }
        }
    }//end addUserArr
    
    // **** Food Functions ****
    
    //Access food in dict
    func returnFoodDict(name:String)->Food?{
        if foodDict.keys.contains(name){
            return foodDict[name]
        }
        return nil
    }
    //Access food in arr
    func returnFoodArr(food:Int)->Food?{
        return foodArr[food]
    }
    
    //Adding food to dictionary alphabetically
    func addFoodDict(food:Food){
        foodDict[food.foodName] = food
    }
    //Adding food to array alphabetically
    func addFoodArr(food:Food){
        for i in 0..<foodArr.count{
            if food < foodArr[i]{
                foodArr.insert(food, at: i)
                break
            }
            if i == foodArr.count-1 {
                foodArr.append(food)
                break
            }
        }
    }//end addFoodArr
    
    // **** Exercise Functions ****
    
    func returnExercise(index:Int)->Exercise?{
        for i in 0..<exerciseArr.count{
            if (i == index){
                print(i)
                return exerciseArr[i]
                
            }
        }
        print("nil")
        return nil
    }

    //Access exercse in dict
    func returnExerciseDict(name:String)->Exercise?{
        if exerciseDict.keys.contains(name){
            return exerciseDict[name]
        }
        return nil
    }
    //Access exercise in arr
    func returnExerciseArr(ex:Int)->Exercise?{
        return exerciseArr[ex]
    }
    
    
    // ***** Functions for adding food/exercise to users acocunt *****
    
    
    //Adding exercise to dictionary alphabetically
    func addUserExerciseDict(ex:Exercised){
        userExerciseDict[ex.name] = ex
    }
    //Adding exercise to array alphabetically
    func addUserExerciseArr(ex:Exercised){
        for i in 0..<userExerciseArr.count{
            if ex < userExerciseArr[i]{
                userExerciseArr.insert(ex, at: i)
                break
            }
            if i == userExerciseArr.count-1 {
                userExerciseArr.append(ex)
                break
            }
        }
    }//end addfoodArr
    
    //Adding food to dictionary alphabetically
    func addUserFoodDict(ex:eatenFood){
        userfoodDict[ex.name] = ex
    }
    //Adding food to array alphabetically
    func addUserFoodArr(ex:eatenFood){
        for i in 0..<userfoodArr.count{
            if ex < userfoodArr[i]{
                userfoodArr.insert(ex, at: i)
                break
            }
            if i == userfoodArr.count-1 {
                userfoodArr.append(ex)
                break
            }
        }
    }//end addfoodArr
    
    func getFoodEaten(index: Int) -> eatenFood? {
        if (userfoodArr.count == 0) {
             return nil
        }
            return userfoodArr[index]
    }
    func getExercised(index: Int)-> Exercised? {
        if(userExerciseArr.count == 0){
            return nil
        }
        return userExerciseArr[index-1]
    }
    
    func isFoodEmpty() -> Bool {
        if(userfoodArr.isEmpty == true){
            return true
        }
        return false
    }
    
    func isExerciseEmpty() -> Bool{
        if (userExerciseArr.isEmpty == true){
            return true
        }
        return false
    }
    
}//end FitnessModel.swift
