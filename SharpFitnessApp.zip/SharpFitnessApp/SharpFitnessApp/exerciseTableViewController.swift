//
//  exerciseTableViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/26/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit
var selectedIndex: Int = 0
class exerciseTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedIndex = indexPath.row
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return FitnessModel.sharedInstance.numExercise()
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Database", for: indexPath)
        let exercise = FitnessModel.sharedInstance.getExercise(index: indexPath.row)
        cell.textLabel?.text = exercise.name
        cell.detailTextLabel?.text = String(exercise.caloriesPerMin)
        cell.imageView?.image = UIImage(named: exercise.name)

        return cell
    }
}
