//
//  SignupViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/13/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {

    var goal:String = ""
    var dob:Int = 0
    var maxCals:Int = 0

    @IBOutlet weak var firstNameText: UITextField!
    @IBOutlet weak var lastNameText: UITextField!
    @IBOutlet weak var currWeightText: UITextField!
    @IBOutlet weak var goalWeightText: UITextField!
    @IBOutlet weak var dobText: UITextField!
    @IBOutlet weak var errorText: UILabel!
    
    let datePicker = UIDatePicker()
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    //if value changes
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        firstNameText.text = ""
        lastNameText.text = ""
        currWeightText.text = ""
        goalWeightText.text = ""
        setupTextFields()
    }
 
    //lose, maintain, gain
    @IBAction func segmentControlWeight(_ sender: UISegmentedControl) {
        //depending on what is selected, goal variable will be assigned to it
        switch segmentedControl.selectedSegmentIndex{
            //lose
            case 0:
            goal = "Lose Weight"
            maxCals = 1200
            //maintain
            case 1:
            goal = "Maintain"
            maxCals = 2000
            //gain
            case 2:
            goal = "Gain Weight"
            maxCals = 2500
        default:
            break
        }
    }
    
    @IBAction func submitButtonAction(_ sender: Any) {
        //check for empty parameters
        if(firstNameText.text?.isEmpty == false && lastNameText.text?.isEmpty == false && currWeightText.text?.isEmpty == false && goalWeightText.text?.isEmpty == false && dobText.text?.isEmpty == false){
            //create new user with information inserted
            let newUser = User(firstName: firstNameText.text!, lastName: lastNameText.text!, email: FitnessModel.myGlobalVariables.email, password: FitnessModel.myGlobalVariables.password, goal:goal, currWeight: Int(currWeightText.text!) ?? 0, goalWeight: Int(goalWeightText.text!) ?? 0, age: Int(dobText.text!) ?? 0, maxCalories:maxCals)
            
            //add new user to db
            FitnessModel.sharedInstance.addUserArr(user: newUser)
            FitnessModel.sharedInstance.addUserDict(user: newUser)
        } else{
            errorText.text = "Please fill in all information correctly before submiting your profile."
        }
    }
    
    //keyboard done button
    func setupTextFields() {
          let toolbar = UIToolbar()
          let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
          let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonTapped))
          
          toolbar.setItems([flexSpace, doneButton], animated: true)
          toolbar.sizeToFit()
          
          firstNameText.inputAccessoryView = toolbar
          lastNameText.inputAccessoryView = toolbar
          currWeightText.inputAccessoryView = toolbar
          goalWeightText.inputAccessoryView = toolbar
          dobText.inputAccessoryView = toolbar
      }
      
      @objc func doneButtonTapped() {
          view.endEditing(true)
      }
}//end signupController
