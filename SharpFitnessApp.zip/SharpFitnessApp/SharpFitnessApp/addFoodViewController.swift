//
//  addFoodViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/26/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

class addFoodViewController: UIViewController {
    var mealSelected = ""
    var generatedFood:eatenFood? = nil
    
    @IBOutlet weak var foodNameOutlet: UITextField!
    @IBOutlet weak var mealSegment: UISegmentedControl!
    @IBOutlet weak var caloriesPerServingOutlet: UITextField!
    @IBOutlet weak var servingsConsumedOutlet: UITextField!
    
    @IBOutlet weak var errorOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        generatedFood = nil
        foodNameOutlet.text = ""
        caloriesPerServingOutlet.text = ""
        servingsConsumedOutlet.text = ""
    }
    
    override func viewDidAppear(_ animated: Bool) {
        generatedFood = nil
        foodNameOutlet.text = ""
        caloriesPerServingOutlet.text = ""
        servingsConsumedOutlet.text = ""
    }

    @IBAction func buttonPressed(_ sender: Any) {
        //update datbase and calories
        if (foodNameOutlet.text?.isEmpty == false && caloriesPerServingOutlet.text?.isEmpty == false && servingsConsumedOutlet.text?.isEmpty == false){
            //add this food to database
            generatedFood = eatenFood(name: "\(foodNameOutlet.text!)", meal: "\(mealSelected)", caloriesPerServing: Int(caloriesPerServingOutlet.text!)!, servingsConsumed: Int( servingsConsumedOutlet.text!)!)
            
            FitnessModel.sharedInstance.userfoodArr.append(generatedFood!)
            
            //Update maxcalories for logged in user
            let caloriesToSubtract = Int(caloriesPerServingOutlet.text!)! * Int(servingsConsumedOutlet.text!)!
            
            //Max Calories update --- might need to change for home screen output
            FitnessModel.sharedInstance.loggedInUser?.maxCalories = FitnessModel.sharedInstance.loggedInUser!.maxCalories - caloriesToSubtract
            
        } else {
            errorOutlet.text = "You must fill in all fields before submitting."
        }
    }
    
    @IBAction func segmentMealPick(_ sender: UISegmentedControl) {
        
        switch mealSegment.selectedSegmentIndex{
        case 0:
            //breakfast
            mealSelected = "Breakfast"
        case 1:
            mealSelected = "Lunch"
        case 2:
            mealSelected = "Snack"
        case 3:
            mealSelected = "Dinner"
        default:
            break
        }
    }
}
