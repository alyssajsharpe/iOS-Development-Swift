//
//  exercised.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 12/1/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//


import Foundation
class Exercised : Comparable{
    
    let name:String
    let minutesExercised:Int
    let caloriesBurned:Int
    
    init(name:String, minutesExercised:Int, caloriesBurned:Int){
        self.name = name
        self.minutesExercised = minutesExercised
        self.caloriesBurned = caloriesBurned
    }

    
    //Comparable functions
    static func < (first: Exercised, second: Exercised) -> Bool{
        if first.name == second.name{
            return first.name < second.name
        } else{
            return first.name < second.name
        }
    }
    
    static func == (first: Exercised, second:Exercised) -> Bool{
        return first.name == second.name
    }
}//end exercise.swift
