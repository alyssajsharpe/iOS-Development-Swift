//
//  user.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/13/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation

class User : Comparable{
    
    //Variables
    let firstName: String
    let lastName: String
    //Username = email
    let email: String
    let password: String
    //maintain, lose, or gain weight
    let goal: String
    let currWeight:Int
    let goalWeight: Int
    let age:Int
    var maxCalories:Int

    //init user variable
    init (firstName:String, lastName:String,email: String, password: String,goal: String, currWeight: Int,
          goalWeight: Int,age:Int, maxCalories:Int){
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
        self.password = password
        self.goal = goal
        self.currWeight = currWeight
        self.goalWeight = goalWeight
        self.age = age
        self.maxCalories = maxCalories
    }
    
    //Comparable functions to compare user
    
    //to help sort by alphabetical
    static func < (first: User, second: User) -> Bool{
        if first.lastName == second.lastName{
            return first.firstName < second.firstName
        } else{
            return first.lastName < second.lastName
        }
    }
    //if last name is the same
    static func == (first: User, second:User) -> Bool{
        return first.lastName == second.lastName
    }
}//end user.swift
