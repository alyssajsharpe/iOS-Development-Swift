//
//  addProgressViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/26/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

class addProgressViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
