//
//  food.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/13/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation
class Food : Comparable{
    
    //Variables
    let foodName:String
    let category:String
    let caloriesPerServing:Int
    
    init(foodName:String, category:String, caloriesPerServing:Int){
        self.foodName = foodName
        //Breakfast, lunch, dinner, snack
        self.category = category
        self.caloriesPerServing = caloriesPerServing
    }
    
    //Comparable functions
    static func < (first: Food, second: Food) -> Bool{
        if first.foodName == second.foodName{
            return first.foodName < second.foodName
        } else{
            return first.foodName < second.foodName
        }
    }
    
    static func == (first: Food, second:Food) -> Bool{
        return first.foodName == second.foodName
    }
}//end food.swift
