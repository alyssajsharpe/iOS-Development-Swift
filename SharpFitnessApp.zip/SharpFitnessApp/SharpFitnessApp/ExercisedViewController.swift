//
//  ExercisedViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 12/3/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

class ExercisedViewController: UIViewController {


    @IBOutlet weak var exerciseOutlet: UILabel!
    @IBOutlet weak var nameOutlet: UILabel!
    @IBOutlet weak var minutesExercisedOutelt: UILabel!
    @IBOutlet weak var caloriesBurnedOutlet: UILabel!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        var exerciseChoice = FitnessModel.sharedInstance.exerciseChoice
        exerciseChoice = FitnessModel.sharedInstance.userExerciseArr[selectedProgress-1]
        
        if(exerciseChoice != nil){
            exerciseOutlet.text = "Exercise"
            nameOutlet.text = exerciseChoice?.name
            minutesExercisedOutelt.text = ("\(exerciseChoice?.minutesExercised ?? 0)")
            caloriesBurnedOutlet.text = ("\(exerciseChoice?.caloriesBurned ?? 0)")
                
        }
    }
}
