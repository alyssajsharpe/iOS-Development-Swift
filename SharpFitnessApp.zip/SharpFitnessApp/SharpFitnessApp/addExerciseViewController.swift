//
//  addExerciseViewController.swift
//  SharpFitnessApp
//
//  Created by Alyssa Sharpe on 10/26/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit

class addExerciseViewController: UIViewController {
    
    var exerciseSelected = FitnessModel.sharedInstance.exerciseSelected
    var addExercise:Exercise? = nil
    var minExercised:Int = 0
    
    @IBOutlet weak var exerciseImage: UIImageView!
    @IBOutlet weak var exerciseNameLabel: UILabel!
    
    @IBOutlet weak var minutesExercisedField: UITextField!
    @IBOutlet weak var errorOutlet: UILabel!
    @IBOutlet weak var sliderOutlet: UISlider!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        findExercise()
    }
    
    
    //finds exercise selected in database and displays it
    func findExercise(){
        exerciseSelected = FitnessModel.sharedInstance.exerciseArr[selectedIndex]
        exerciseImage.image = UIImage(named: exerciseSelected!.name)
        exerciseNameLabel.text = exerciseSelected?.name
    }//end findExercise

    //Update calories
    func reportExercise(){
        
        //calculating calories burned from input
        let caloriesBurned = minExercised * Int(exerciseSelected!.caloriesPerMin)

        //creating a exercised object to insert into exercise progress database
        let exerciseFinished = Exercised(name: exerciseNameLabel.text!, minutesExercised: minExercised, caloriesBurned: caloriesBurned)
        FitnessModel.sharedInstance.userExerciseArr.append(exerciseFinished)
        
        //Updating maxCalories - adding calories since exercising burns calories
        FitnessModel.sharedInstance.loggedInUser?.maxCalories = FitnessModel.sharedInstance.loggedInUser!.maxCalories + caloriesBurned
    }//end reportExercise

    @IBAction func buttonPressed(_ sender: Any) {
        if(minutesExercisedField.text?.isEmpty == false){
            //add exercise to DB & update calories
            reportExercise()
        } else{
            errorOutlet.text = "You must fill in all fields before submitting this exericse."
        }
    }//end buttonPressed

    @IBAction func sliderAction(_ sender: Any) {
        //updating field and varibale to hold minutes exercised
        minutesExercisedField.text = "\(sliderOutlet.value.rounded())"
        minExercised = Int(sliderOutlet.value.rounded())
    }//end slderAction
}
