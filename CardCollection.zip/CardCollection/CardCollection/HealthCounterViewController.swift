//
//  HealthCounterViewController.swift
//  CardCollection
//
//  Created by Mariah Rible and Alyssa Sharpe on 6/8/20.
//  Copyright © 2020 SOU. All rights reserved.
//

import UIKit

class HealthCounterViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        topStepperOutlet.value = 20
        bottomStepperOutlet.value = 20
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var topStepperLabel: UILabel!
    @IBOutlet weak var topStepperOutlet: UIStepper!
    @IBOutlet weak var bottomStepperLabel: UILabel!
    @IBOutlet weak var bottomStepperOutlet: UIStepper!
    
    @IBAction func topStepper(_ sender: UIStepper) {
        topStepperLabel.text = "\(Int(topStepperOutlet.value))"
    }
    
    @IBAction func bottomStepper(_ sender: UIStepper) {
        bottomStepperLabel.text = "\(Int(bottomStepperOutlet.value))"
    }
   
    @IBAction func resetButton(_ sender: UIButton) {
        //reseeting life counter
        topStepperOutlet.value = 20
        topStepperLabel.text = "20"
        bottomStepperOutlet.value = 20
        bottomStepperLabel.text = "20"
        //Setting min value for steppers
        topStepperOutlet.minimumValue = -50
        bottomStepperOutlet.minimumValue = -50
    }
    
}
