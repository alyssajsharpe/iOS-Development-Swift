//
//  CardModel.swift
//  CardCollection
//
//  Created by Mariah Rible and Alyssa Sharpe  on 5/26/20.
//  Copyright © 2020 SOU. All rights reserved.
//

import Foundation
class CardModel {
    
    //Singleton
    static let sharedInstance = CardModel()
    
    //Dictionary
    var cardDict: [String:Card] = [:]
    
    //var to hold card to add to collection
    var cardChoice:Card? = nil
    var cardChoiceIndex:Int? = nil
    //Arrays
    var cardArr:[Card] = [] //array for card database
    var collection:[Card] = [] // array for card collection
    
    init() {
        //all the cards
        let karn = Card(name: "Karn, the Great Creator", number: "001", scarcity: "Rare", color: "Colorless", type: "Legendary Planeswalker", toughness: "5")
        let ugin = Card(name: "Ugin, the Ineffable", number: "002", scarcity: "Rare", color: "Colorless", type: "Legendary Planeswalker", toughness: "4")
        let uginConj = Card(name: "Ugin's Conjurant", number: "003", scarcity: "Uncommon", color: "Colorless", type: "Creature", power: "0", toughness: "0")
        let ajaniPride = Card(name: "Ajani's Pridemate", number: "004", scarcity: "Uncommon", color: "White", type: "Creature", power: "2", toughness: "2")
        let battlePromo = Card(name: "Battlefield Promotion", number: "005", scarcity: "Common", color: "White", type: "Instant")
        let bondDis = Card(name: "Bond of Discipline", number: "006", scarcity: "Uncommon", color: "White", type: "Sorcery")
        let bulGiant = Card(name: "Bulwark Giant", number: "007", scarcity: "Common", color: "White", type: "Creature", power: "3", toughness: "6")
        let charmStray = Card(name: "Charmed Stray", number: "008", scarcity: "Common", color: "White", type: "Creature", power: "1", toughness: "1")
        let defStrike = Card(name: "Defiant Strike", number: "009", scarcity: "Common", color: "White", type: "Instant")
        let divineArrow = Card(name: "Divine Arrow", number: "010", scarcity: "Common", color: "White", type: "Instant")
        let enforceGriff = Card(name: "Enforcer Griffin", number: "011", scarcity: "Common", color: "White", type: "Creature", power: "3", toughness: "4")
        let finOfGlory = Card(name: "Finale of Glory", number: "012", scarcity: "Mythic", color: "White", type: "Sorcery")
        let gideon = Card(name: "Gideon Blackblade", number: "013", scarcity: "Mythic", color: "White", type: "Planeswalker", toughness: "4")
        let gideonSac = Card(name: "Gideon's Sacrifice", number: "014", scarcity: "Common", color: "White", type: "Instant")
        let gideonTri = Card(name: "Gideon's Triumph", number: "015", scarcity: "Uncommon", color: "White", type: "Instant")
        let godOketra = Card(name: "God-Eternal Oketra", number: "016", scarcity: "Mythic", color: "White", type: "Creature", power: "3", toughness: "6")
        let grateAppar = Card(name: "Grateful Apparition", number: "017", scarcity: "Uncommon", color: "White", type: "Creature", power: "1", toughness: "1")
        let igniteBeacon = Card(name: "Ignite the Beacon", number: "018", scarcity: "Rare", color: "White", type: "Instant")
        let ironKrovod = Card(name: "Ironclad Krovod", number: "019", scarcity: "Common", color: "White", type: "Creature", power: "1", toughness: "5")
        let lawEn = Card(name: "Law-Rune Enforcer", number: "020", scarcity: "Common", color: "White", type: "Creature", power: "1", toughness: "2")
        let loxSerg = Card(name: "Loxodon Sergeant", number: "021", scarcity: "Common", color: "White", type: "Creature", power: "3", toughness: "3")
        let makeBatt = Card(name: "Makeshift Battalion", number: "022", scarcity: "Common", color: "White", type: "Creature", power: "3", toughness: "2")
        let martyrCause = Card(name: "Martyr for the Cause", number: "023", scarcity: "Common", color: "White", type: "Creature", power: "2", toughness: "2")
        let parhelion = Card(name: "Parhelion II", number: "024", scarcity: "Rare", color: "White", type: "Vehicle", power: "5", toughness: "5")
        let pounceLynx = Card(name: "Pouncing Lynx", number: "025", scarcity: "Common", color: "White", type: "Creature", power: "2", toughness: "1")
        let prisonRealm = Card(name: "Prison", number: "026", scarcity: "Uncommon", color: "White", type: "Enchantment")
        let rallyWings = Card(name: "Rally of Wings", number: "027", scarcity: "Uncommon", color: "White", type: "Instant")
        let ravAtWar = Card(name: "Ravnica at War", number: "028", scarcity: "Rare", color: "White", type: "Sorcery")
        let risePop = Card(name: "Rising Populace", number: "029", scarcity: "Common", color: "White", type: "Creature", power: "2", toughness: "2")
        let singleCom = Card(name: "Single Combat", number: "030", scarcity: "Rare", color: "White", type: "Sorcery")
        let sunbladeAngel = Card(name: "Sunblade Angel", number: "031", scarcity: "Uncommon", color: "White", type: "Creature", power: "3", toughness: "3")
        let teyo = Card(name: "Teyo, the Shieldmage", number: "032", scarcity: "Uncommon", color: "White", type: "Planeswalker", toughness: "5")
        let teyoLight = Card(name: "Teyo's Lightshield", number: "033", scarcity: "Common", color: "White", type: "Creature", power: "0", toughness: "3")
        let tomik = Card(name: "Tomik, Distinguished Advokist", number: "034", scarcity: "Rare", color: "White", type: "Creature", power: "2", toughness: "3")
        let toppleStat = Card(name: "Topple the Statue", number: "035", scarcity: "Common", color: "White", type: "Instant")
        let trustPeg = Card(name: "Trusted Pegasus", number: "036", scarcity: "Common", color: "White", type: "Creature", power: "2", toughness: "2")
        let wanderer = Card(name: "The Wanderer", number: "037", scarcity: "Uncommon", color: "White", type: "Planeswalker", toughness: "5")
        let wandStrike = Card(name: "Wanderer's Strike", number: "038", scarcity: "Common", color: "White", type: "Sorcery")
        let warScreech = Card(name: "War Screecher", number: "039", scarcity: "Common", color: "White", type: "Creature", power: "1", toughness: "3")
        let ashSkulk = Card(name: "Ashiok's Skulker", number: "040", scarcity: "Common", color: "Blue", type: "Creature", power: "3", toughness: "5")
        let augBolas = Card(name: "Augur of Bolas", number: "041", scarcity: "Uncommon", color: "Blue", type: "Creature", power: "1", toughness: "3")
        let avenEt = Card(name: "Aven Eternal", number: "042", scarcity: "Common", color: "Blue", type: "Creature", power: "2", toughness: "2")
        let bondIn = Card(name: "Bond of Insight", number: "043", scarcity: "Uncommon", color: "Blue", type: "Sorcery")
        let callDis = Card(name: "Callous Dismissal", number: "044", scarcity: "Common", color: "Blue", type: "Sorcery")
        let comEnd = Card(name: "Commence the Endgame", number: "045", scarcity: "Rare", color: "Blue", type: "Instant")
        let contPlan = Card(name: "Contentious Plan", number: "046", scarcity: "Common", color: "Blue", type: "Sorcery")
        let crushDis = Card(name: "Crush Dissent", number: "047", scarcity: "Common", color: "Blue", type: "Instant")
        let errVis = Card(name: "Erratic Visionary", number: "048", scarcity: "Common", color: "Blue", type: "Creature", power: "1", toughness: "3")
        let eterSky = Card(name: "Eternal Skylord", number: "049", scarcity: "Uncommon", color: "Blue", type: "Creature", power: "3", toughness: "3")
        let fblthp = Card(name: "Fblthp", number: "050", scarcity: "Rare", color: "Blue", type: "Creature", power: "1", toughness: "1")
        let finOfRev = Card(name: "Finale of Revelation", number: "051", scarcity: "Mythic", color: "Blue", type: "Sorcery")
        let fluxChan = Card(name: "Flux Channeler", number: "052", scarcity: "Uncommon", color: "Blue", type: "Creature", power: "2", toughness: "2")
        let godKefnet = Card(name: "God-Eternal Kefnet", number: "053", scarcity: "Mythic", color: "Blue", type: "Creature", power: "4", toughness: "5")
        let jace = Card(name: "Jace, Wielder of Mysteries", number: "054", scarcity: "Rare", color: "Blue", type: "Planeswalker", toughness: "4")
        let jaceTri = Card(name: "Jace's Triumph", number: "055", scarcity: "Uncommon", color: "Blue", type: "Sorcery")
        let kasmina = Card(name: "Kasmina, Enigmatic Mentor", number: "056", scarcity: "Uncommon", color: "Blue", type: "Planeswalker", toughness: "5")
        let kasminaTran = Card(name: "Kasmina's Transmutation", number: "057", scarcity: "Common", color: "Blue", type: "Enchantment")
        
        
        
        //the card array for sorting by number
        cardArr = [karn, ugin, uginConj, ajaniPride, battlePromo, bondDis, bulGiant, charmStray, defStrike, divineArrow, enforceGriff, finOfGlory, gideon, gideonSac, gideonTri, godOketra, grateAppar, igniteBeacon, ironKrovod, lawEn, loxSerg, makeBatt, martyrCause, parhelion, pounceLynx, prisonRealm, rallyWings, ravAtWar, risePop, singleCom, sunbladeAngel, teyo, teyoLight, tomik, toppleStat, trustPeg, wanderer, wandStrike, ashSkulk, augBolas, avenEt, bondIn, callDis, comEnd, contPlan, crushDis, errVis, eterSky, fblthp, finOfRev, fluxChan, godKefnet, jace, jaceTri, kasmina, kasminaTran]
        //the dictionary for searching by name
        cardDict = ["\(karn.name)":karn,
                "\(ugin.name)":ugin,
                "\(uginConj.name)":uginConj,
                "\(ajaniPride.name)":ajaniPride,
                "\(battlePromo.name)":battlePromo,
                "\(bondDis.name)":bondDis,
                "\(bulGiant.name)":bulGiant,
                "\(charmStray.name)":charmStray,
                "\(defStrike.name)":defStrike,
                "\(divineArrow.name)":divineArrow,
                "\(enforceGriff.name)":enforceGriff,
                "\(finOfGlory.name)":finOfGlory,
                "\(gideon.name)":gideon,
                "\(gideonSac.name)":gideonSac,
                "\(gideonTri.name)":gideonTri,
                "\(godOketra.name)":godOketra,
                "\(grateAppar.name)":grateAppar,
                "\(igniteBeacon.name)":igniteBeacon,
                "\(ironKrovod.name)":ironKrovod,
                "\(lawEn.name)":lawEn,
                "\(loxSerg.name)":loxSerg,
                "\(makeBatt.name)":makeBatt,
                "\(martyrCause.name)":martyrCause,
                "\(parhelion.name)":parhelion,
                "\(pounceLynx.name)":pounceLynx,
                "\(prisonRealm.name)":prisonRealm,
                "\(rallyWings.name)":rallyWings,
                "\(ravAtWar.name)":ravAtWar,
                "\(risePop.name)":risePop,
                "\(singleCom.name)":singleCom,
                "\(sunbladeAngel.name)":sunbladeAngel,
                "\(teyo.name)":teyo,
                "\(teyoLight.name)":teyoLight,
                "\(tomik.name)":tomik,
                "\(toppleStat.name)":toppleStat,
                "\(trustPeg.name)":trustPeg,
                "\(wanderer.name)":wanderer,
                "\(wandStrike)":wandStrike,
                "\(warScreech)":warScreech,
                "\(ashSkulk.name)":ashSkulk,
                "\(augBolas.name)":augBolas,
                "\(avenEt.name)":avenEt,
                "\(bondIn.name)":bondIn,
                "\(callDis.name)":callDis,
                "\(comEnd.name)":comEnd,
                "\(contPlan.name)":contPlan,
                "\(crushDis.name)":crushDis,
                "\(errVis.name)":errVis,
                "\(eterSky.name)":eterSky,
                "\(fblthp.name)":fblthp,
                "\(finOfRev)":finOfRev,
                "\(fluxChan.name)":fluxChan,
                "\(godKefnet.name)":godKefnet,
                "\(jace.name)":jace,
                "\(jaceTri)":jaceTri,
                "\(kasmina.name)":kasmina,
                "\(kasminaTran.name)":kasminaTran]
    }//init
    
    //get the total number of cards in the card database
    func numCards() -> Int { return cardArr.count }
    
    //get the total number of cards in the users collection
    func numCardCollection() -> Int { return collection.count }
    
    //return a card at the index specified from the database
    func getCard(index: Int) -> Card { return cardArr[index] }
    
    //get a card from the users collection, as long as the collection isn't empty
    func getCardCollection(index: Int) -> Card? {
        if (collection.count == 0) {
             return nil
        } else {
            return collection[index]
        }//if
    }//func getCardCollection
    
    func getIndex(card:Card) -> Int{
        var index:Int = 0
        for i in 0..<collection.count{
            if(card.number == collection[i].number){
                index = i
                return index
            }
        }
        return -1
    }
    //Adding card to array & dict
    func addCard(card: Card) {
        collection.append(card)
    }//func addCard
    
    //Check if card is in collection
    func checkCard(card:Card) -> Bool{
        for i in 0..<cardArr.count{
            if(card.name == cardArr[i].name){
                return false
            }//if
        }//for
        return true
    }//func checkCard
    
    //Check if card is in collection
    func checkInCollection(card:Card) -> Bool{
        for i in 0..<collection.count{
            if(card.name == collection[i].name || "(Foil)" + card.name == collection[i].name){
                return true
            }//if
        }//for
        return false
    }//func checkCard
    
    func deleteCard(card:Card) {
        for i in 0..<collection.count{
            if(card.name == collection[i].name){
                collection.remove(at: i)
                break
            }//if
        }//for
    }//func deleteCard
    
    //determine if the users collection is empty
    func isCollectionEmpty()-> Bool {
        if (collection.isEmpty) {
            return true
        } else {
            return false
        }//if
    }//isCollectionEmpty
}//class CardModel
