//
//  DatabaseTableViewController.swift
//  CardCollection
//
//  Created by Mariah Rible and Alyssa Sharpe on 5/29/20.
//  Copyright © 2020 SOU. All rights reserved.
//

import UIKit
var mySecondIndex: Int = 0
class DatabaseTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }//func viewDidLoad
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        mySecondIndex = indexPath.row
    }
    
    //specifies the number of rows
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return CardModel.sharedInstance.numCards()
        }//func tableView
            
    //Providing a cell object for each row
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Database", for: indexPath)

            let card = CardModel.sharedInstance.getCard(index: indexPath.row)
            cell.textLabel?.text = card.name
            cell.detailTextLabel?.text = card.number
            cell.imageView?.image = UIImage(named: card.number)
                
            return cell
        }
            
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            return "Database Collection"
    }
}
