//
//  CollectionViewController.swift
//  CardCollection
//
//  Created by Mariah Rible and Alyssa Sharpe on 5/26/20.
//  Copyright © 2020 SOU. All rights reserved.
//

import UIKit
var myIndex:Int = 0

class CollectionViewController: UITableViewController, UISearchResultsUpdating{
    //Array for holding cards user searched for
    var filteredCards:[Card] = []
    let searchController = UISearchController(searchResultsController: nil)
    
    //Search Bar functions https://www.raywenderlich.com/4363809-uisearchcontroller-tutorial-getting-started
    
    func updateSearchResults(for searchController: UISearchController) {
      let searchBar = searchController.searchBar
      filterContentForSearchText(searchBar.text!)
    }
    var isSearchBarEmpty: Bool {
        return searchController.searchBar.text?.isEmpty ?? true
    }
    
    var isFiltering: Bool {
        return searchController.isActive && !isSearchBarEmpty
    }

    func filterContentForSearchText(_ searchText: String) {
        if CardModel.sharedInstance.getCardCollection(index: myIndex) != nil{
        filteredCards = CardModel.sharedInstance.collection.filter { (card: Card) -> Bool in
            return card.name.lowercased().contains(searchText.lowercased())            }
        }//end if
        self.tableView.reloadData()
    }//end filterContentForSearchText
    
    override func viewDidLoad(){
        super.viewDidLoad()
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }//func viewDidLoad

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
        CardModel.sharedInstance.collection.sort(by: <)
    }
    
    //If cell was picked
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //What row user picked
        myIndex = indexPath.row
        var card:Card? = nil
        //store the card
        if(isFiltering){
            card = CardModel.sharedInstance.collection[indexPath.row]
            myIndex = CardModel.sharedInstance.getIndex(card: card!)
            card = filteredCards[myIndex]
            //Update card chosen
            CardModel.sharedInstance.cardChoice = card
            CardModel.sharedInstance.cardChoiceIndex = myIndex
        } else {
            card = CardModel.sharedInstance.collection[indexPath.row]
            CardModel.sharedInstance.cardChoice = card
            CardModel.sharedInstance.cardChoiceIndex = myIndex
        }
    }

    //following tableView functions retreived from https://www.ralfebert.de/ios-examples/uikit/uitableviewcontroller/

    //specifies the number of rows
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Checking if user is searching
        if isFiltering {
            return filteredCards.count
        }
        return CardModel.sharedInstance.numCardCollection()
    }//func tableView
    
    //displays the data in the table cells
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CardCell", for: indexPath)
        //Card
        if var card = CardModel.sharedInstance.getCardCollection(index: indexPath.row){
            if (CardModel.sharedInstance.isCollectionEmpty() == false) {
                //Search function
                if(isFiltering){
                    card = filteredCards[indexPath.row]
                } else {
                    card = CardModel.sharedInstance.getCardCollection(index: indexPath.row)!
                }
                cell.textLabel?.text = card.name
                cell.detailTextLabel?.text = card.number
                cell.imageView?.image = UIImage(named: card.number)
            } else {
                cell.textLabel?.text = ""
                cell.detailTextLabel?.text = ""
            }//if
        }//outter if
        return cell
    }//func
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "War of the Spark"
    }//func
}
