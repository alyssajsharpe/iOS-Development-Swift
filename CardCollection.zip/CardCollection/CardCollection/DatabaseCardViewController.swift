//
//  DatabaseCardViewController.swift
//  CardCollection
//
//  Created by Mariah Rible and Alyssa Sharpe on 5/29/20.
//  Copyright © 2020 SOU. All rights reserved.
//

import UIKit

class DatabaseCardViewController: UIViewController {
    //Variables
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var inCollectionLabel: UILabel!
    @IBOutlet weak var imageOutletDisplay: UIImageView!
    @IBOutlet weak var scarcityLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var powerLabel: UILabel!
    @IBOutlet weak var toughnessLabel: UILabel!
    @IBOutlet weak var foilLabel: UILabel!
    @IBOutlet var numAddStepper: UIStepper!
    @IBOutlet var numAddLabel: UILabel!
    @IBOutlet var foilSwitch: UISwitch!
    
    //shows the value of the stepper on a label
    @IBAction func increment(_ sender: UIStepper) {
        numAddLabel.text = "\(Int(numAddStepper.value))"
    }

    //add the specified number of cards to the users collection
    @IBAction func addButton(_ sender: UIButton) {
        var card = CardModel.sharedInstance.cardArr[mySecondIndex]
        let value:Int = Int(numAddStepper.value)
        if foilSwitch.isOn {
            card.name = "(Foil)" + card.name
        }
        for _ in 0..<value {
            CardModel.sharedInstance.addCard(card: card)
        }//for
        inCollectionLabel.text = "Added \(value) cards to collection."
    }//func addButton
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }//func viewDidLoad
    
    override func viewWillAppear(_ animated: Bool) {
        //switch should initially be off
        foilSwitch.isOn = false
        //If turned on it will display error: CardCollection[30826:8129255] invalid mode 'kCFRunLoopCommonModes' provided to CFRunLoopRunSpecific
        //From our research, this is an error due to an Apple bug
        
        //display the selected card
        var cardChoice = CardModel.sharedInstance.cardChoice
        cardChoice = CardModel.sharedInstance.cardArr[mySecondIndex]
        if (CardModel.sharedInstance.checkInCollection(card: cardChoice!) == false){
            inCollectionLabel.text = "This card is not in your collection yet."
        } else {
            inCollectionLabel.text = "You already have this card."
        }//if
        
        if(cardChoice != nil) {
            nameLabel.text = cardChoice!.name
            typeLabel.text = cardChoice!.type
            scarcityLabel.text = "Scarcity: \(String(describing: cardChoice!.scarcity))"
       
            if cardChoice?.power != nil {
                powerLabel.text = cardChoice!.power
            } else {
                powerLabel.text = "None"
            }//if
            
            if cardChoice?.toughness != nil {
                toughnessLabel.text = cardChoice!.toughness
            } else {
                toughnessLabel.text = "None"
            }//if
            
            imageOutletDisplay.image = UIImage(named: cardChoice!.number)
        }//if
    }//func viewWillAppear
}//class DB controller
