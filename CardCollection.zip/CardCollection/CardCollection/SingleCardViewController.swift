//
//  SingleCardViewController.swift
//  CardCollection
//
//  Created by Mariah Rible and Alyssa Sharpe on 5/26/20.
//  Copyright © 2020 SOU. All rights reserved.
//

import UIKit

class SingleCardViewController: UIViewController {
    //labels
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var scarcityLabel: UILabel!
    @IBOutlet weak var powerLabel: UILabel!
    @IBOutlet weak var toughnessLabel: UILabel!
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var CardImageDisplay: UIImageView!

   //action that removes a card from the users collection
    @IBAction func deleteCardAction(_ sender: UIBarButtonItem) {
        let cardToDelete = CardModel.sharedInstance.cardChoice
        if (cardToDelete != nil) {
            if CardModel.sharedInstance.checkInCollection(card: cardToDelete!){
                CardModel.sharedInstance.deleteCard(card: cardToDelete!)
                errorLabel.text = "\(cardToDelete!.name) has been deleted from your collection."
            } else {
                errorLabel.text = "The card you have tried to delete is not in your collection."
            }//if
        }//if
    }//func
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }//func viewDidLoad
    
    override func viewWillAppear(_ animated: Bool) {
        
        let cardChoice = CardModel.sharedInstance.cardChoice
        if(cardChoice != nil)   {
            nameLabel.text = cardChoice!.name
            typeLabel.text = cardChoice!.type
            scarcityLabel.text = "Scarcity: \(String(describing: cardChoice!.scarcity))"
            errorLabel.text = ""
            
            if cardChoice?.power != nil {
                powerLabel.text = cardChoice!.power
            } else {
                powerLabel.text = "N/A"
            }//if
            
            if cardChoice?.toughness != nil {
                toughnessLabel.text = cardChoice!.toughness
            } else {
                toughnessLabel.text = "N/A"
            }//if
            CardImageDisplay.image = UIImage(named: cardChoice!.number)
        }//if
    }//func viewWillAppear
}//class SingleCardView
