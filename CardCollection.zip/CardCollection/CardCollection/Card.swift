//
//  Card.swift
//  CardCollection
//
//  Created by Mariah Rible and Alyssa Sharpe on 5/26/20.
//  Copyright © 2020 SOU. All rights reserved.
//

import Foundation

struct Card: Comparable {
    
    //stored properties
    var name:String
    let number:String
    let scarcity:String
    let color:String
    let type:String
    let power:String? //optional because not all cards have power
    let toughness:String? //optional because not all cards have toughness
    
    //initializer for creature cards
    init(name:String, number:String, scarcity:String, color:String, type:String, power:String, toughness:String) {
        self.name = name
        self.number = number
        self.scarcity = scarcity
        self.color = color
        self.type = type
        self.power = power
        self.toughness = toughness
    }//Card init
    
    //initialzier for instants/sorceries/enchantments
    init(name:String, number:String, scarcity:String, color:String, type:String) {
        self.name = name
        self.number = number
        self.scarcity = scarcity
        self.color = color
        self.type = type
        power = nil
        toughness = nil
    }//Card init
    
    //initializer for planeswalkers
    init(name:String, number:String, scarcity:String, color:String, type:String, toughness:String) {
        self.name = name
        self.number = number
        self.scarcity = scarcity
        self.color = color
        self.type = type
        power = nil
        self.toughness = toughness
    }//Card init
    
    //to sort collection by number regardless of order the user entered
    static func < (lhs: Card, rhs: Card) -> Bool {
        return lhs.number < rhs.number
    }//func <
    
}//struct Card
