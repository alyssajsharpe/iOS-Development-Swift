//
//  ViewController.swift
//  PrizePickerApp
//
//  Created by Alyssa Sharpe on 4/30/20.
//  Copyright © 2020 SOU. All rights reserved.
//  CS356 LAB 3

import UIKit

//Constant strings
let mainTitle = "Welcome to PrizePicker!"
let winner = "We have a winner!"
let startover = "Start Over"
let choose = "Choose a Door"
let gl = "Good Luck!"



class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    var theModel = PrizeDoors(chest: PrizeChest(isPopulated: true))
    var titleLabel: UILabel?
    //Welcome
    @IBOutlet weak var statusDisplay: UILabel!
    //Door
    @IBOutlet weak var prizeDisplay: UILabel!
    //Start over button
    @IBOutlet weak var resetButton: UIButton!
    //Jackpot label
    @IBOutlet weak var ifJackpot: UILabel!
    //Hint button
    @IBOutlet weak var Hint: UIButton!
    @IBOutlet weak var youWon: UILabel!
    
    //if door is clicked
    @IBAction func prizePicked(_ sender: UIButton) {
        let labelText = sender.titleLabel?.text ?? ""
        let intLabelText = Int(labelText) ?? 0
        choosePrize(doorNum: intLabelText)
    }

    @IBAction func startOver(_ sender: UIButton) {
        theModel.reset()
        youWon.isHidden = true
        statusDisplay.text = mainTitle
        prizeDisplay.text = choose
        ifJackpot.text = gl
        resetButton.isEnabled = false
    }
    
    @IBAction func hintButton(_ sender: UIButton) {
        let door = theModel.doorNum!+1
        prizeDisplay.text = String("Hint: don't choose door \(door)")
    }
    func choosePrize(doorNum: Int){
        let prize = theModel.returnPrize(doorNum: doorNum-1)
        if(prize?.name == "BOOBY PRIZE"){
            ifJackpot.text = "OH NO!"
            prizeDisplay.text = "BOOBY PRIZE!"
        } else if(prize?.isJackpot == true){
            ifJackpot.text = "JACKPOT!"
            youWon.isHidden = false
            prizeDisplay.text = prize?.output
        } else {
            youWon.isHidden = false
            ifJackpot.text = "No jackpot"
            prizeDisplay.text = prize?.output
        }
        statusDisplay.text = winner
        resetButton.isEnabled = true
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String(row + 1)
    }
    
    // called when a selection is made
    // recall that the first row is row 0
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        choosePrize(doorNum: row + 1)
    }

    // UIPickerViewDataSource protocol methods
    
    // # of components in each row
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // number of rows
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 3 // this should really be declared as a constant!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

