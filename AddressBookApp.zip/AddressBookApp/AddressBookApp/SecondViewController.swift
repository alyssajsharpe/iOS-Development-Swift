//
//  SecondViewController.swift
//  AddressBookApp
//
//  Created by user168926 on 5/14/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit
class SecondViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {

    @IBOutlet weak var pickerViewOutlet: UIPickerView!
    @IBOutlet weak var nameDisplay: UILabel!
    @IBOutlet weak var phoneDisplay: UILabel!
    @IBOutlet weak var emailDisplay: UILabel!


    func choosePerson(personNum: Int){
        //Creating person variable to hold person returned
        if let returnedPerson = MVC.sharedInstance.returnPersonArr(person: personNum){
            //Ouput persons information
            nameDisplay.text = returnedPerson.firstName + " " + returnedPerson.lastName
            phoneDisplay.text = returnedPerson.phoneNumber
            emailDisplay.text = returnedPerson.email
        }
    }
    
    // UIPickerViewDelegate protocol methods
    // what to display on a specific row
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String("\(MVC.sharedInstance.returnPersonArr(person:row)!.firstName) \(MVC.sharedInstance.returnPersonArr(person:row)!.lastName)")
        
    }
    
    // called when a selection is made
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        choosePerson(personNum: row)
    }

    // UIPickerViewDataSource protocol methods
    
    // # of components in each row
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // number of rows
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return MVC.sharedInstance.personArr.count
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //updating pickerView
        pickerViewOutlet.reloadAllComponents()
        //Setting view to row 0
        pickerViewOutlet.selectRow(0,inComponent: 0, animated:true)
        //Resetting labels
        nameDisplay.text = NONE
        phoneDisplay.text = NONE
        emailDisplay.text = NONE
  }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

