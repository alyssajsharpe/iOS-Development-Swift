//
//  MVC.swift
//  AddressBookApp
//
//  Created by user168926 on 5/14/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation

class MVC {
    
    // the globally accessible shared instance
    static let sharedInstance = MVC()
    // properties
    var inputString: String = ""
    
    //Creating empty dictionary
    var dict:[String: Person] = [:]
    //Creating empty person array
    var personArr:[Person] = []
    
    init(){
        let person1 = Person(firstName: "Maggie", lastName: "Vanderberg", phoneNumber: "541-552-6974", email: "vanderbem@sou.edu")
        let person2 = Person(firstName: "Daniel", lastName: "Defreez", phoneNumber: "541-552-6135", email: "defreezd@sou.edu")
        let person3 = Person(firstName: "Donald", lastName: "Trump", phoneNumber: "202-456-1111", email: "potus@whitehouse.gov")
        let person4 = Person(firstName: "Kevin", lastName: "Sahr", phoneNumber: "541-552-6978", email: "sahrk@sou.edu")
        let person5 = Person(firstName: "Alyssa", lastName: "Sharpe", phoneNumber: "925-658-2400", email: "sharpea@sou.edu")
        //Adding people to dictionary
        dict = [person1.firstName + " " + person1.lastName: person1, person2.firstName + " " + person2.lastName: person2, person3.firstName + " " + person3.lastName:person3, person4.firstName + " " + person4.lastName:person4, person5.firstName + " " + person5.lastName:person5]
        //Adding people to array alphabetically manually
        personArr.append(person2)
        personArr.append(person4)
        personArr.append(person5)
        personArr.append(person3)
        personArr.append(person1)
    }
    
    //Access person in dictionary
    func returnPerson(name: String) -> Person? {
        if dict.keys.contains(name){
                return dict[name]
            }
            return nil
        }
    //Access person in array
    func returnPersonArr(person: Int) -> Person? {
        return personArr[person]
    }
    
    //Adding person to dictionary alphabetically
    func addPersonDict(person:Person){
        dict[person.firstName + " " + person.lastName] = person
    }
    //Adding person to array alphabetically
    func addPersonArr(person:Person){
        for i in 0..<personArr.count{
            if person < personArr[i]{
                personArr.insert(person, at: i)
                break
            }
            if i == personArr.count-1 {
                personArr.append(person)
                break
            }
        }
    }
}//end MVC class
