//
//  Person.swift
//  AddressBookApp
//
//  Created by user168926 on 5/14/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import Foundation

class Person : Comparable{
    
    //person variables
    let firstName:String
    let lastName: String
    let phoneNumber:String
    let email:String
    
    //variable init
    init(firstName:String, lastName:String, phoneNumber:String, email:String){
        self.firstName = firstName
        self.lastName = lastName
        self.phoneNumber = phoneNumber
        self.email = email
    }
    
    //Comparable functions
    static func < (first: Person, second: Person) -> Bool{
        if first.lastName == second.lastName{
            return first.firstName < second.firstName
        } else{
            return first.lastName < second.lastName
        }
    }
    
    static func == (first: Person, second:Person) -> Bool{
        return first.lastName == second.lastName
    }
    
    //Desc function
    func desc() -> String {
        return String(format: "Name: %@ %@ Phone Number: %@ Email: %@", firstName,lastName,phoneNumber,email)
    }
}//end person class
