//
//  ThirdViewController.swift
//  AddressBookApp
//
//  Created by user168926 on 5/14/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit
//Constant strings
let statusDisplay = "Please fill in information to add a person of your choice to the address book."
let success = "Successfully added new person to address book"
let errDuplicate = "ERROR: Person is already in address book."
let errInvalid = "ERROR: Input was invalid, cannot add to address book."

class ThirdViewController: UIViewController {

    //Labels
    @IBOutlet weak var statusLabelDisplay: UILabel!
    @IBOutlet weak var buttonLabel: UIButton!
    
    //TextFields: What user enters
    @IBOutlet weak var firstNameTextBox: UITextField!
    @IBOutlet weak var lastNameTextBox: UITextField!
    @IBOutlet weak var phoneTextBox: UITextField!
    @IBOutlet weak var emailTextBox: UITextField!
    
    @IBAction func buttonAction(_ sender: UIButton) {
        //Dismissing keyboard for all responses
        firstNameTextBox.resignFirstResponder()
        lastNameTextBox.resignFirstResponder()
        phoneTextBox.resignFirstResponder()
        emailTextBox.resignFirstResponder()
        
        //Checking if input is empty
        if (firstNameTextBox.text?.isEmpty == false && lastNameTextBox.text?.isEmpty == false && phoneTextBox.text?.isEmpty == false && emailTextBox.text?.isEmpty == false){
            //Creating a person with input values from textboxes
            let newPerson = Person(firstName: firstNameTextBox.text!, lastName: lastNameTextBox.text!, phoneNumber: phoneTextBox.text!, email: emailTextBox.text!)
            //Checking if person exists in dictionary
            if (MVC.sharedInstance.returnPerson(name: "\(firstNameTextBox.text! + " " + lastNameTextBox.text!)") == nil) {
                //Adding newPerson to array and dictionary
                MVC.sharedInstance.addPersonArr(person: newPerson)
                MVC.sharedInstance.addPersonDict(person: newPerson)
                statusLabelDisplay.text = success
                print(MVC.sharedInstance.personArr)
                print(MVC.sharedInstance.dict)
                
            } else{
                statusLabelDisplay.text = errDuplicate
            }
        } else {
            statusLabelDisplay.text = errInvalid
       }
    } //end buttonAction
    
    override func viewWillAppear(_ animated: Bool) {
         super.viewWillAppear(animated)
        //Resetting text boxes
        firstNameTextBox.text = ""
        lastNameTextBox.text = ""
        phoneTextBox.text = ""
        emailTextBox.text = ""
        statusLabelDisplay.text = statusDisplay
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
