//
//  FirstViewController.swift
//  AddressBookApp
//
//  Created by user168926 on 5/14/20.
//  Copyright © 2020 Alyssa Sharpe. All rights reserved.
//

import UIKit
let NOTFOUND = "NOT FOUND"
let NONE = "NONE"
class FirstViewController: UIViewController {
    
    //Labels for text
    @IBOutlet weak var nameDisplay: UILabel!
    @IBOutlet weak var numberDisplay: UILabel!
    @IBOutlet weak var emailDisplay: UILabel!
    @IBOutlet weak var textFieldDisplay: UITextField!
    
    
    @IBAction func textField(_ sender: UITextField) {
        textFieldDisplay.resignFirstResponder()
        MVC.sharedInstance.inputString = textFieldDisplay.text!
        print(MVC.sharedInstance.inputString)

        if let tempPerson = MVC.sharedInstance.returnPerson(name:MVC.sharedInstance.inputString){
                //Name was found
                nameDisplay.text = tempPerson.firstName + " " + tempPerson.lastName
                numberDisplay.text = tempPerson.phoneNumber
                emailDisplay.text = tempPerson.email
        } else {
            //Name was not found
            nameDisplay.text = NOTFOUND
            numberDisplay.text = NOTFOUND
            emailDisplay.text = NOTFOUND
        }
    }//end textField
    
    override func viewWillAppear(_ animated: Bool) {
         super.viewWillAppear(animated)
        //Resetting labels
        nameDisplay.text = NONE
        numberDisplay.text = NONE
        emailDisplay.text = NONE
        textFieldDisplay.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}//end firstViewController

